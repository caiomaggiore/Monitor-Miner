DHT22_PIN = 4  # GPIO pin for DHT22 sensor
WIFI_ESSID = 'your_wifi_ssid'
WIFI_PASSWORD = 'your_wifi_password'
