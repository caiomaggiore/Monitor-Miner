This directory contains examples that demonstrate sub-applications.
